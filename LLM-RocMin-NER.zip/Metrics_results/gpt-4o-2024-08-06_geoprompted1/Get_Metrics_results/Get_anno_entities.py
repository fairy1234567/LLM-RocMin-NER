import json
import re
import os

# 定义提取岩石和矿物实体的正则表达式
rock_pattern = re.compile(r'<([^<>]+)>')
mineral_pattern = re.compile(r'\[([^\[\]]+)\]')

def read_json_lines(file_path):
    """
    逐行读取JSON文件并返回解析后的数据列表。
    """
    data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            try:
                data.append(json.loads(line))
            except json.JSONDecodeError as e:
                print(f"JSON decoding failed: {e} for line: {line}")
    return data

def process_data(data):
    """
    处理每条数据，提取岩石和矿物实体。
    """
    processed_data = []
    for item in data:
        answer_text = item['answer']
        file_path = item['file']
        ID = item['ID']

        # 提取岩石实体
        rocks = rock_pattern.findall(answer_text)

        # 提取矿物实体
        minerals = mineral_pattern.findall(answer_text)

        # 生成结果字典
        result_item = {
            "ID": ID,
            "file": file_path.split('/')[-1],  # 仅保留文件名
            "ROC": rocks,
            "MIN": minerals
        }

        # 添加到结果列表
        processed_data.append(result_item)
    return processed_data

def save_processed_data(processed_data, output_file):
    """
    将处理后的数据保存到新的JSON文件中。
    """
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w', encoding='utf-8') as outfile:
        for dict_item in processed_data:
            outfile.write(json.dumps(dict_item, ensure_ascii=False) + "\n")
    print("转换完成！")

def main():

    # 输入和输出文件路径
    input_json = "../../../recog_result/gpt-4o-2024-08-06_geoprompted1.json"
    out_json_dir = "../"
    out_json_file = os.path.join(out_json_dir, "entities.json")

    # 读取答案JSON文件
    data = read_json_lines(input_json)

    # 处理数据
    processed_data = process_data(data)

    # 输出结果（可选）
    for result in processed_data:
        print(result)

    # 保存处理后的数据
    save_processed_data(processed_data, out_json_file)

if __name__ == "__main__":
    main()
