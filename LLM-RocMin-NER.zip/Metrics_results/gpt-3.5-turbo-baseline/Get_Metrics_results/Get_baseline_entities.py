import json
import re
import os

def transform_data(input_data):
    """
    从输入数据中提取ID、文件名、岩石实体和矿物实体。
    """
    ID = input_data["ID"]
    file = input_data["file"].split('/')[-1]

    # 提取answer字段中的岩石实体和矿物实体
    answer = input_data["answer"]
    roc_match = re.search(r'岩石实体：([^；]*)', answer)
    min_match = re.search(r'矿物实体：([^。]*)', answer)

    ROC = extract_entities(roc_match)
    MIN = extract_entities(min_match)

    return {
        "ID": ID,
        "file": file,
        "ROC": ROC,
        "MIN": MIN
    }

def extract_entities(match):
    """
    从匹配结果中提取实体列表。
    """
    if match:
        entities_str = match.group(1).split("\n")[0]
        return [] if entities_str == '无' else re.split(r'[、，]', entities_str)
    return []

def read_and_transform_data(input_file):
    """
    读取输入文件并转换数据。
    """
    transformed_data = []
    with open(input_file, 'r', encoding='utf-8') as infile:
        for line in infile:
            try:
                data = json.loads(line)
                transformed_data.append(transform_data(data))
            except json.JSONDecodeError as e:
                print(f"Error decoding JSON on line: {line}\n{e}")
    return transformed_data

def save_transformed_data(transformed_data, output_file):
    """
    将转换后的数据保存到输出文件。
    """
    with open(output_file, 'w', encoding='utf-8') as outfile:
        for dict_item in transformed_data:
            outfile.write(json.dumps(dict_item, ensure_ascii=False) + "\n")

def main():
    # 输入和输出文件路径
    input_json = "../../../recog_result/gpt-3.5-turbo_baseline.json"
    out_json_dir = "../"
    out_json_file = os.path.join(out_json_dir, "entities.json")

    # 创建输出目录（如果不存在）
    os.makedirs(out_json_dir, exist_ok=True)

    # 读取和转换数据
    transformed_data = read_and_transform_data(input_json)

    # 保存转换后的数据
    save_transformed_data(transformed_data, out_json_file)

    print("转换完成！")

if __name__ == "__main__":
    main()