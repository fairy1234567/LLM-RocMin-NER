import json
import os


def load_json_lines(file_path):
    """
    逐行读取JSON文件并返回解析后的数据列表。
    """
    data = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            try:
                data.append(json.loads(line))
            except json.JSONDecodeError as e:
                print(f"Error decoding JSON on line: {line}\n{e}")
    return data


def match_annotations_with_predictions(annotations, predictions):
    """
    匹配annotations和predictions中的数据，并返回匹配的结果列表。
    """
    prediction_dict = {item['file']: item for item in predictions}
    matched_data = []

    for annotation in annotations:
        file_name = annotation['file']
        if file_name in prediction_dict:
            matched_prediction = prediction_dict[file_name]
            matched_data.append({
                'annotation': annotation,
                'prediction': matched_prediction
            })

    return matched_data


def save_json(data, file_path):
    """
    将数据保存到指定的JSON文件中。
    """
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as output_file:
        json.dump(data, output_file, ensure_ascii=False, indent=4)


def main():
    # 读取annotation.json文件
    annotations = load_json_lines('../../../data/test_anno.json')

    # 读取prediction.json文件
    prediction_json_dir = "../"  #"inter_3.5_results/" "inter_4o_results/" "category_pre_directly_inter_4o_results/"
    prediction_json_file = os.path.join(prediction_json_dir, "entities.json")

    predictions = load_json_lines(prediction_json_file)

    # 匹配annotations和predictions中的数据
    matched_data = match_annotations_with_predictions(annotations, predictions)

    # 输出匹配结果
    for match in matched_data:
        print("Annotation:", match['annotation'])
        print("Prediction:", match['prediction'])
        print()

    # 将匹配结果保存到一个新的JSON文件中
    out_json_file = os.path.join(prediction_json_dir, "matched_result.json")
    save_json(matched_data, out_json_file)

    print("匹配完成！")


if __name__ == "__main__":
    main()
